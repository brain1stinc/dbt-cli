from metricflow_semantic_interfaces.type_enums import TimeGranularity

DEFAULT_ENV_PLACEHOLDER = "DBT_DEFAULT_PLACEHOLDER"

SECRET_PLACEHOLDER = "$$$DBT_SECRET_START$$${}$$$DBT_SECRET_END$$$"

PIN_PACKAGE_URL = (
    "https://docs.getdbt.com/docs/package-management#section-specifying-package-versions"
)

DBT_HOME_DIR_NAME = ".dbt"
USER_SETTINGS_FILE_NAME = "user_settings.yml"
DBT_PROJECT_FILE_NAME = "dbt_project.yml"
VARS_FILE_NAME = "vars.yml"
PACKAGES_FILE_NAME = "packages.yml"
DEPENDENCIES_FILE_NAME = "dependencies.yml"
PACKAGE_LOCK_FILE_NAME = "package-lock.yml"
MANIFEST_FILE_NAME = "manifest.json"
SEMANTIC_MANIFEST_FILE_NAME = "semantic_manifest.json"
OSI_DOCUMENT_FILE_NAME = "osi_document.json"
OSI_DIRECTORY_NAME = "osi"
SUPPORTED_OSI_VERSIONS = frozenset({"0.1.0", "0.1.1"})
LEGACY_TIME_SPINE_MODEL_NAME = "metricflow_time_spine"
LEGACY_TIME_SPINE_GRANULARITY = TimeGranularity.DAY
MINIMUM_REQUIRED_TIME_SPINE_GRANULARITY = TimeGranularity.DAY
PARTIAL_PARSE_FILE_NAME = "partial_parse.msgpack"
PACKAGE_LOCK_HASH_KEY = "sha1_hash"
CATALOGS_FILE_NAME = "catalogs.yml"
RUN_RESULTS_FILE_NAME = "run_results.json"
CATALOG_FILENAME = "catalog.json"
SOURCE_RESULT_FILE_NAME = "sources.json"
